package com.lnt.sample1;

public class Calc {
    static int add(int a, int b){
        return (a+b);
    }
}
