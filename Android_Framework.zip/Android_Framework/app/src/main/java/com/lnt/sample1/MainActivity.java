package com.lnt.sample1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2;
    public static TextView tv1;
    Button bt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1 = (Button)findViewById(R.id.bt1);
        ed1 = (EditText)findViewById(R.id.ed1);
        ed2 = (EditText)findViewById(R.id.ed2);
        tv1 = (TextView)findViewById(R.id.tv1);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //int a=Integer.parseInt(ed1.getText().toString());
                //int b=Integer.parseInt(ed2.getText().toString());
                //int result=Calc.add(a,b);
                //tv1.setText(String.valueOf(result));
                //Toast.makeText(getApplicationContext(),String.valueOf(result), Toast.LENGTH_LONG).show();
                ThreadDemo th1=new ThreadDemo();
                th1.start();
            }
        });
    }
}